import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
from firebase_admin import storage
import flask
from flask import jsonify
from flask import Response
from flask import request
from datetime import datetime, timedelta
import helper
import os
import google.auth
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import *
from flask_cors import CORS

# Credentials to access server
cred = credentials.Certificate('key.json')
newapp = firebase_admin.initialize_app(cred, name="streamPosts")
db = firestore.client(app=newapp)

app = flask.Flask(__name__)
CORS(app)

headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Max-Age': '3600'
        }

@app.route('/', methods=['POST', 'DELETE', 'PUT', 'GET', 'PATCH'])
def main_Posts(request):
    """The entry point for the API that calls a specific function
    depending on the type and path of the received request"""

    if request.method == "POST" and request.path == "/posts":
        return createPost(request)
    if request.method == "OPTIONS":
        response = Response()
        response.headers['Access-Control-Allow-Methods'] = 'GET, OPTIONS, POST'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        response.headers['Access-Control-Allow-Origin'] = '*'
        return response
        

    
    # if request.method == "PATCH" and request.path == "/posts":
    #     return deletePost(request)

# @app.after_request
# def add_headers(response):
#     """Add headers to API response to enable CORS"""

#     response.headers.add('Access-Control-Allow-Origin', '*')
#     response.headers.add('Access-Control-Allow-Methods', 'POST, GET, PUT, DELETE, PATCH')
#     response.headers.add('Access-Control-Allow-Headers', 'Content-Type, Authorization')
#     return response

def uploadImage(newData, request):
    """Function responsible for uploading the image associated
    with a post"""
    #TODO: check image size is less than 1.5mb

    # References
    bucketname = 'ashesistream.appspot.com'
    bucket = storage.bucket(name=bucketname,app=newapp) #image db
    currUserDoc =helper.getUserExact(newData['email'])
    currUserDict = currUserDoc.to_dict()

    # Get user post count
    postCount = currUserDict['postcount']

    # set image name
    newData['imagename']= currUserDict['id'] + str(postCount+1)

    # Upload to bucket
    image = request.files['image']
    filename = newData['imagename']

    blob = bucket.blob(filename) #create filename for image
    blob.upload_from_string(image.read(), content_type=image.content_type)

    
    # generate image url
    newData['imageurl'] = blob.generate_signed_url(
    version="v4",
    expiration=timedelta(minutes=10080),
    method="GET",)

   
    return newData


@app.route('/posts', methods=['POST'])
def createPost(request):
    """method that allows a post to be created
    Posts are limited to 280 characters and one image"""

    # Connect to tables
    postsTable = helper.postsDB()
    # usersPostsTable = usersTable.collection('posts')

    # Load request data and get reference to user
    newData = request.form.to_dict()

    # Check if user exists in database
    if not helper.checkifUserExists(newData['email']):
        return jsonify("User Does Not Exist"), 404, headers

    # Get reference to user
    currUserDoc = helper.getUserExact(newData['email'])

    # Check that post length is <= 280 characters
    if len(newData['text'])>280:
        return jsonify("The post is too long"), 400, headers

    # Add username, email and post time
    currUserDict = currUserDoc.to_dict()
    newData['name'] = currUserDict['name']
    newData['email'] = currUserDict['email']
    newData['posttime'] = datetime.now().strftime("%a %d %B, %I:%M:%S %p")
    newData['sortTime'] = datetime.now()


    # Set postid
    newData['postid'] = newData['email'] + str(int(currUserDoc.to_dict()['postcount'])+1)

    # Add users name and email to post
    currUserDict = currUserDoc.to_dict() 
    newData['username'] = currUserDict['name']
    newData['email'] = currUserDict['email']


    # Check if there is an image and upload final post data
    if newData['hasimage'] == 'true':
        updatedData = uploadImage(newData,request)
        # Add post
        postsTable.add(updatedData)
        helper.userPostsDB(newData['email']).add(newData)  # users posts
    else:
        postsTable.add(newData)
        helper.userPostsDB(newData['email']).add(newData)  # users posts

    # Increment post count and email friends
    currUserDoc.reference.update({"postcount": firestore.Increment(1)})
    notifyFriends(newData['email'])

    return jsonify("Post Created"), 201, headers

def notifyFriends(email):
    """A function that notifies friends when a user makes a post"""

    if helper.sendEmail(email):
        return jsonify("All emails were sent"), 200 
    else:
        return jsonify("Emails failed to send"), 202
    


if __name__ == '__main__':
    app.run()