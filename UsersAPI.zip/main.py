import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import flask
from flask import jsonify
import re
from datetime import datetime
import helper
from flask_cors import CORS
from flask import Response
from flask import request

# Credentials to access server
cred = credentials.Certificate('key.json')
newapp = firebase_admin.initialize_app(cred, name="streamUsers")
db = firestore.client(app=newapp)

app = flask.Flask(__name__)
CORS(app)

headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PATCH, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Max-Age': '3600'
        }


@app.route('/', methods=['POST', 'DELETE', 'PUT', 'GET', 'PATCH'])
def main_Users(request):
    """The entry point for the API that calls a specific function
    depending on the type and path of the received request"""

    if request.method == "POST" and request.path == "/users":
        return addUser(request)
    if request.method == "GET" and request.path.startswith("/users"):
        return getUser(request)
    if request.method == "PATCH" and request.path == "/users":
        return updateUser(request)
    if request.method == "POST" and request.path == "/users/addfriend":
        return addFriend(request)
    if request.method == "OPTIONS":
        response = Response()
        response.headers['Access-Control-Allow-Methods'] = 'GET, OPTIONS, POST, PATCH'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        response.headers['Access-Control-Allow-Origin'] = '*'
        return response

# @app.after_request
# def addCorsHeader(response):
#     response.headers['Access-Control-Allow-Origin'] = '*'
#     response.headers['Access-Control-Allow-Methods'] = 'POST, DELETE, PUT, GET, PATCH'
#     response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
#     response.headers['Access-Control-Max-Age'] = '3600'
#     return response

def getUser(request):
    "method for getting user data"

    newData = request.args.get('email')

    # Check if user exists
    if not helper.checkifUserExists(newData):
        return jsonify("User does not exist"), 404

    userData = helper.getUserExact(newData).to_dict()

    relevantData = {
        "name": userData['name'],
        "email": userData['email'],
        "food": userData['food'],
        "major": userData['major'],
        "movie": userData['movie'],
        "yeargroup":userData['yeargroup'],
        "postcount":userData['postcount'],
        "friendcount":userData['friendcount'],
        "residence" :userData['residence'],
        "dob": userData['dob']
    }

    return jsonify(relevantData), 200, headers


def addUser(request):
    """A method that adds a user to the database"""

    newData = request.get_json()

    # Check if user already exists in database
    if helper.checkifEmailExists(newData['email']) or helper.checkifIdExists(newData["id"]):
        return jsonify("User Already Exists"), 409, headers

    # Validate email format
    if not helper.validateEmail(newData['email']):
        return jsonify("Incorrect Email"), 400, headers

    # Validate Major
    if not helper.validateMajor(newData['major']):
        return jsonify("Invalid Major"), 400, headers

    #TODO: Validate fields

    # Set post count to zerro and Add new user
    newData['postcount'] = 0
    newData['friendcount'] = 0
   
    doc_ref = db.collection('users').document(newData['email'])
    doc_ref.set(newData)
    # helper.usersDB().add(newData)

    # Get user ref and create friends sub collection
    # newUser = helper.getUserExact(newData['id']).reference
    following_col = helper.userFriendsDB(newData['email'])
    # following_col.document().set({
    #     'friendid': 'ignore'
    # })

    # create posts sub collection for user
    posts_col = helper.userPostsDB(newData['email'])
    # posts_col.document().set({
    #     'postid': 'ignore'
    # })

    return jsonify(newData['email']), 200, headers

def updateUser(request):
    """Function that updates the details of a user except
    id, name, and email"""

    newData = request.get_json()

    # Check that only valid fields are trying to be updated
    if not helper.validateFields(newData.keys()):
        return jsonify("Illegal Change Requested"), 400, headers

    # Check if user exists
    if not helper.checkifUserExists(newData['email']):
        return jsonify("User not found"), 404, headers

    # Get the requested user from the database
    targetUserQuery = helper.getUserExact(newData['email'])

    # Get direct reference to user doc
    targetUserDoc = targetUserQuery.reference

    # Update the necessary fields
    updateData = {}
    for key in newData.keys():
        # put all key-values except id in dict
        if key != "id" and key != "email":
            updateData[key] = newData[key]

    # Update user with the dictionary content
    if updateData:
        targetUserDoc.update(updateData)
        return jsonify(newData['email']), 200, headers
    else:
        return jsonify("No fields to update"), 400, headers


def addFriend(request):
    """A method that makes 2 users friends"""

    # Get recipient and sender ids
    newData = request.get_json()
    senderEmail = newData['senderEmail']
    recipientEmail = newData['recipientEmail']

    # Check existence
    if not (helper.checkifUserExists(senderEmail) and helper.checkifUserExists(recipientEmail)):
        return jsonify("One of the users does not exist"), 400, headers

    # Check Friendship
    if helper.checkFriendship(request):
        return jsonify("Users are already friends"), 400, headers

    # get reference and document of both records
    recipientDoc = helper.getUserExact(recipientEmail)
    senderDoc = helper.getUserExact(senderEmail)
    senderDict = senderDoc.to_dict()
    recipientDict = recipientDoc.to_dict()

    # get both friend lists
    recipFriendList = helper.userFriendsDB(recipientEmail)
    senderFriendList = helper.userFriendsDB(senderEmail)

    # create new records for both people
    recipFriendList.add({"email": senderDict['email'],"yeargroup": senderDict['yeargroup'],"name": senderDict['name'] })
    senderFriendList.add({"email": recipientDict['email'], "yeargroup": recipientDict['yeargroup'], "name": recipientDict['name']})

    # Increment friend counts
    recipientDoc.reference.update({"friendcount": firestore.Increment(1)})
    senderDoc.reference.update({"friendcount": firestore.Increment(1)})

    return jsonify(senderEmail, recipientEmail), 201, headers

if __name__ == '__main__':
    app.run()

