import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
from firebase_admin import storage
import flask
from flask import jsonify
from datetime import datetime
import re
import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
import os
import json
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Credentials to access server
cred = credentials.Certificate('key.json')
newapp = firebase_admin.initialize_app(cred, name="helperAPI")
db = firestore.client(app=newapp)

app = flask.Flask(__name__)


def usersDB():
    """Helper method for connecting to the user database"""
    return db.collection('users')

def postsDB():
    """Helper method for connecting to the posts database"""
    return db.collection('posts')

def userPostsDB(email):
    """Helper method for connecting to a users posts sub-collection"""
    targetUser = usersDB().where('email','==',email).get()[0].reference
    postsCollection = targetUser.collection('posts')

    return postsCollection

def userFriendsDB(email):
    """Helper method for connecting to a users friends sub-collection"""
    targetUser = usersDB().where('email', '==', email).get()[0].reference
    friendsCollection = targetUser.collection('friends')

    return friendsCollection

def getUser(email):
    """Helper method that returns a list containing a specified user"""
    targetUser = usersDB().where('email','==',email).get()

    return targetUser

def getUserExact(email):
    """Helper method that gets the snapshot of the exact user from the list"""
    return getUser(email)[0]

def validateEmail(email):
    """Helper method for validating an email address"""
    pattern = r"^[a-zA-Z0-9._%+-]+@ashesi\.edu\.gh$"
    if not re.match(pattern,email):
        return False
    else:
        return True

def validateMajor(major):
    majors = ['Computer Science', 'Engineering', 'Management Information Systems',
              'Business Administration']

    if major not in majors:
        return False
    else:
        return True
def checkifUserExists(email):
    """Helper method for checking if a user exists"""

    targetUserQuery = getUser(email)
    # idCheck = usersDB().where("id","==",getUserExact.to_dict()["id"])
    
    # Check if ID exists
    if len(targetUserQuery) == 0:
        return False
    else:
        return True

def checkifIdExists(userid):
    user = usersDB().where("id", "==",userid).get()

    if len(user) == 0:
        return False
    else:
        return True



def checkifEmailExists(email):
    """a helper function for checking if an email is already in use"""

    


    checkEmail = usersDB().where('email', '==',email).get()
    if len(checkEmail) == 0:
        return False
    else:
        return True


def validateFields(keys):
    """Helper funtion for checking if fields are legal
    returns true if they are legal and false if illegal"""
    for key in keys:
        if key not in ["dob","food","major","movie","residence","yeargroup","id","email"]:
            return False

    return True

def checkFriendship(request):
    """Helper method that checks if  2 people are already friends
    returns false if not friends, and true if friends"""
    newData = request.get_json()

    # Check if user is sending request to self
    if newData['senderEmail'] == newData['recipientEmail']:
        return True

    friendsList = userFriendsDB(newData['senderEmail']) #get user friends list
    query = friendsList.where('email','==',newData['recipientEmail']).get()

    if len(query) < 1:
        return False
    else:
        return True

def getMailList(email):
    """A helper method that gets the email addresses of all a persons friends"""

    # Connect to friends db
    friendsDb = userFriendsDB(email).stream()

    mailList = []
    for friend in friendsDb:
        doc = friend.to_dict()
        # if doc['friendid']!= "ignore":
        mailList.append(doc['email'])

    return mailList


# def sendEmail(userid):
#     """Helper function responsible for sending the email"""
#
#     # Get name of post creator and list of email recipients
#     postCreator = getUserExact(userid).to_dict()['name']
#     recipients = getMailList(userid)
#
#     count = 0
#     for recipient in recipients:
#
#         message = Mail(
#             from_email='sblank.blankson@gmail.com',
#             to_emails= recipient,
#             subject='New post from ' + postCreator,
#             html_content='<strong>Your Friend just made a new post! Login to see</strong>')
#         try:
#             sg = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
#             response = sg.send(message)
#             print(response.status_code)
#             print(response.body)
#             print(response.headers)
#         except Exception as e:
#             print(e.message)
#
#         count +=1
#
#     return len(recipients), count


def sendEmail(email):
    # Set up the SMTP server, secure context and credentials
    smtp_server = "smtp.office365.com"
    port = 587
    context = ssl.create_default_context()
    sender_email = os.environ.get('SENDER_EMAIL')
    sender_password = os.environ.get('SENDER_PASSWORD')

    # Get name of post creator and list of email recipients
    postCreator = getUserExact(email).to_dict()['name']
    recipients = getMailList(email)

    # Compose the email message
    message = MIMEMultipart()
    message['From'] = sender_email
    message['Bcc'] = ", ".join(recipients)
    message['Subject'] = postCreator + " has made a new post!"
    body = postCreator + " has made a new post!. Sign into Stream to check it out"
    message.attach(MIMEText(body, 'plain'))


    # Send the email
    with smtplib.SMTP(smtp_server, port) as server:
        server.starttls(context=context)
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, [], message.as_string())

    return True










